Advanced Statistics
===========
Show more statistics about you Elgg installation

Contents
-----------

1. Features
2. ToDo

1. Features
-----------
Shows the following statistics

- Users
- Groups
- Content
- Activity
- Widgets
- System

2. ToDo
-----------

- More statistics!!!